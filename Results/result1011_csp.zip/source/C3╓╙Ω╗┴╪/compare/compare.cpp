#include<bits/stdc++.h>
using namespace std;

int main(){
//	do{
//		system(".exe");
//		system(".exe");
//		system(".exe");
//	}while(!system("fc .out .out"));
	system("fc ds.out ex_ds2.out");
	return 0;
}
