#include<bits/stdc++.h>
using namespace std;
int main() {
	freopen("count.in","r",stdin);
	freopen("count.out","w",stdout);
	cout<<0;
	return 0;
}
