#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N=5005;
inline int read(){
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-') f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-48;ch=getchar();}
	return x*f;
}
int n,l,r,tot=-1;
string s;
signed main(){
	freopen("kel.in","r",stdin);
	freopen("kel.out","w",stdout);
	n=read();
	l=read(),r=read();
	cout<<"Shinomiya";
	return 0;
}
