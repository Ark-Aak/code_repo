#include<bits/stdc++.h>
#define int long long
#define N 1000006
using namespace std;

signed main() {
    freopen("kel.in", "r", stdin);
    freopen("kel.out", "w", stdout);
    cout << "Shinomiy"; 
    return 0;
}

