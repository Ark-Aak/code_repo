#include<bits/stdc++.h>
using namespace std;
int n,x;
int main()
{
	freopen("fight.in","r",stdin);
	freopen("fight.out","w",stdout);
	cin>>n>>x;
	for(int i=1;i<n;i++)
	{
		int y;
		cin>>y;
	}
	for(int i=1;i<=n;i++)
		printf("%.12llf\n",1.0/pow(2,(double)log2(n)));
	return 0;
}
