#include<bits/stdc++.h>
#define ll long long
#define N 200005
using namespace std;
double n;
int main(){
    freopen("fight.in","r",stdin);
    freopen("fight.out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;i++)printf("%.15lf\n",1/n);
    return 0;
}