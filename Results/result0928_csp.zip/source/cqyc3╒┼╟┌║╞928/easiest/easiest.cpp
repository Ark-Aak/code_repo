#include <bits/stdc++.h>
#define ll long long
using namespace std;
int main(){
	freopen("easiest.in","r",stdin);
	freopen("easiest.out","w",stdout);
int n,m;cin>>n>>m;
while(m--) cout<<2<<endl; 
	return 0;
}

