#include <bits/stdc++.h>
using namespace std;

int main() {
	freopen("easiest.in", "w", stdout);
	puts("7 3\n\
2 7 3 4 1 6 5\n\
1 2 6 4 6\n\
1 1 7 4 5\n\
2 1 7 3 7");
	freopen("easiest.out", "w", stdout);
	puts("2\n4\n9");
} 
