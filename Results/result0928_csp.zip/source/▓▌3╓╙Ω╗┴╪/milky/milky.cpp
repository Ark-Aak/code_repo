#include<bits/stdc++.h>
using namespace std;

#define int long long 
#define F(i,a,b) for(int i=a;i<=b;i++)

const int N=1e6+5;

string s;

int n,l,r;

vector<int>v; 

signed main(){
	cin>>s;
	cin>>n;
	return 0;
}
