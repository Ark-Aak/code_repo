#include<bits/stdc++.h>
using namespace std;
int main() {
	int n;
	cin>>n;cin>>n;
	while(n--) {
		cout<<0<<endl;
	}
	return 0;
}
