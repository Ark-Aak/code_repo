#include<bits/stdc++.h>
#define int long long 
using namespace std;
signed main() {
	freopen("geometry.in","r",stdin);
	freopen("geometry.out","w",stdout);
	cout<<-1;
	return 0;
}
