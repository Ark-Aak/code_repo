#include<bits/stdc++.h>
#define ll long long
#define N 200005
#define endl "\n" 
using namespace std;
const ll mod=1e9+7;
int main(){
    freopen("grid.in","r",stdin);
    freopen("grid.out","w",stdout);
    cout<<12;
    return 0;
}