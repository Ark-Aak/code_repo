#include<iostream>
main(){freopen("game.in","r",stdin);freopen("game.out","w",stdout);
int t;std::cin>>t;while(t--)std::cout<<"tie\n";}
