#include <cstdio>
main(){freopen("imp.out", "w", stdout);puts("0");}
